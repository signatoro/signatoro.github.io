var searchData=
[
  ['rendercomponent_0',['renderComponent',['../class_game_object.html#afd95fdc99eb81e60f528e83d67b7065d',1,'GameObject']]],
  ['rotation_1',['rotation',['../class_game_object.html#ac55f6ebdf4cfbab508680ad7290fb26c',1,'GameObject']]]
];
