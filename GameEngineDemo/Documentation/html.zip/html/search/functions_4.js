var searchData=
[
  ['gameobject_0',['GameObject',['../class_game_object.html#a40a4aacdc3568ef16805cb18b21881e4',1,'GameObject::GameObject(Component &amp;renderComponent)'],['../class_game_object.html#af6e834a510de9e6bc4d4508853452c17',1,'GameObject::GameObject(float locationX, float locationY, float scaleX, float scaleY, float rotation, Component &amp;renderComponent)']]],
  ['getgameobject_1',['GetGameObject',['../class_script_component.html#adf9043686322d3d659625365b32b82d8',1,'ScriptComponent']]],
  ['geth_2',['GetH',['../class_game_object.html#adbbd3e5c06a5ed24217fedbc390dd520',1,'GameObject']]],
  ['getinstance_3',['GetInstance',['../class_resource_manager.html#acb3f8ecc7b3de8c1c7ac956ce5114d47',1,'ResourceManager']]],
  ['getr_4',['GetR',['../class_game_object.html#a130948bee13353e8ce86508d912d2ff8',1,'GameObject']]],
  ['getresource_5',['GetResource',['../class_resource_manager.html#a46186330327f0876b50341082ea5433f',1,'ResourceManager']]],
  ['getsdlwindow_6',['getSDLWindow',['../class_s_d_l_graphics_program.html#a42e9554ec5b497551530bd5a8ca9585f',1,'SDLGraphicsProgram']]],
  ['getw_7',['GetW',['../class_game_object.html#a39ec7257fe9dc1e375736cf8dcf71c5f',1,'GameObject']]],
  ['getx_8',['GetX',['../class_game_object.html#a54f27b720690d96be9f293196102ee84',1,'GameObject']]],
  ['gety_9',['GetY',['../class_game_object.html#afb3ee521767363c4323a63d965affcdd',1,'GameObject']]]
];
