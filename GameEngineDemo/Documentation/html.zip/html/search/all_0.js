var searchData=
[
  ['addcomponent_0',['AddComponent',['../class_game_object.html#ac815a4545f47afcbdada3800373c03f0',1,'GameObject']]],
  ['addgameobject_1',['AddGameObject',['../class_s_d_l_graphics_program.html#afb8d3e324d5858174f93dca6f76a1729',1,'SDLGraphicsProgram']]]
];
