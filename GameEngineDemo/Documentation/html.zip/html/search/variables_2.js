var searchData=
[
  ['scalex_0',['scaleX',['../class_game_object.html#a991ce9335ef2e1cc9dc58aa87f3a0b2f',1,'GameObject']]],
  ['scaley_1',['scaleY',['../class_game_object.html#ac461ab067f5fb37e9e2115dc3572ab29',1,'GameObject']]]
];
