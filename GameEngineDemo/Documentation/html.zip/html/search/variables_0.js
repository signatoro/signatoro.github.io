var searchData=
[
  ['locationx_0',['locationX',['../class_game_object.html#ae4f65052497a751a22e915c779701992',1,'GameObject']]],
  ['locationy_1',['locationY',['../class_game_object.html#a5a034f7350caec2738a9911ad387acec',1,'GameObject']]]
];
